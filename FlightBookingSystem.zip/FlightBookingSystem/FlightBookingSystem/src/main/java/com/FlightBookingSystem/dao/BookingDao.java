package com.FlightBookingSystem.dao;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.FlightBookingSystem.entity.Booking;
import com.FlightBookingSystem.entity.Passenger;
import com.FlightBookingSystem.entity.Payment;
import com.FlightBookingSystem.enums.Status;
import com.FlightBookingSystem.exception.RecordNotAvailableException;
import com.FlightBookingSystem.repository.BookingRepository;

@Repository
public class BookingDao {
	@Autowired
	private BookingRepository bookingRepository;
	
	public Booking createBooking(Booking booking) {
		return bookingRepository.save(booking);
	}

	public Optional<Booking> getBookingById(int id) {
		return bookingRepository.findById(id);
	}
	
	public List<Booking> getAllBooking(){
		return bookingRepository.findAll();	
	}
	
	public List<Booking> getBookingByFlightId(Integer id) {
		return bookingRepository.getByFlightId(id);
	}
	
	public List<Booking> getBookingByDate(LocalDate bookingDate) {
		return bookingRepository.getBookingByDate(bookingDate);
	}
	
	public List<Booking> getBookingByStatus(Status status) {
		return bookingRepository.findByStatus(status);
	}
	
	public List<Passenger> getPassengerByBooking(int id) {
		return bookingRepository.getPassengerByBookinId(id);
	}
	
	public Optional<Payment> getPaymentByBookingId(int id) {
		return bookingRepository.getPaymentByBookinId(id);
	}
	
	public void deleteBooking(Booking booking) {
		bookingRepository.delete(booking);
	}
	
	//CREATING THE PAGE AND SORTING TOGETHER
		public Page<Booking> getBookingByPageAndSorted(int pageNumber , int pageSize , String field){
			Page<Booking> bookings = bookingRepository.findAll(PageRequest.of(pageNumber, pageSize ,Sort.by(field).ascending()));
			if(!bookings.isEmpty()){
				return bookings;
			}
			else {
				throw new RecordNotAvailableException("No records are present");
			}
		}
}
