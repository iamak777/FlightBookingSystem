package com.FlightBookingSystem.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Repository;

import com.FlightBookingSystem.entity.Passenger;
import com.FlightBookingSystem.exception.RecordNotAvailableException;
import com.FlightBookingSystem.repository.PassengerRepository;

@Repository
public class PassengerDao {
	@Autowired
	private PassengerRepository passengerRepository;
	
	public Passenger addPassenger(Passenger passenger) {
		return passengerRepository.save(passenger);
	}
	
	public Optional<Passenger> getPassengerById(int id) {
		return passengerRepository.findById(id);
	}
	
	public List<Passenger> getAllPassenger(){
		return passengerRepository.findAll();
	}
	
	public Passenger updatePassenger(Passenger passenger) {
		return passengerRepository.save(passenger);
	}
	
	public Void deletePassenger(Passenger passenger) {
		passengerRepository.delete(passenger);
		return null;
	} 
	
	public Optional<Passenger> getPassengerByContactNumber(Long contactNumber) {
		return passengerRepository.findByContactNumber(contactNumber);
	}
	
	//CREATING THE PAGE AND SORTING TOGETHER
			public Page<Passenger> getPassengerByPageAndSorted(int pageNumber , int pageSize , String field){
				Page<Passenger> bookings = passengerRepository.findAll(PageRequest.of(pageNumber, pageSize ,Sort.by(field).descending()));
				if(!bookings.isEmpty()){
					return bookings;
				}
				else {
					throw new RecordNotAvailableException("No records are present");
				}
			}
	
}
