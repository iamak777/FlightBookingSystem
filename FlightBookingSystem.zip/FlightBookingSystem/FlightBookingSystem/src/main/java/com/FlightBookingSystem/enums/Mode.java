package com.FlightBookingSystem.enums;

public enum Mode {
	UPI,
	DEBITCARD,
	CREDITCARD,
	QRCODE
}
