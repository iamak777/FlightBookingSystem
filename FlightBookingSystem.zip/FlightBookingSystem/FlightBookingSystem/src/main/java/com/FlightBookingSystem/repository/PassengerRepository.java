package com.FlightBookingSystem.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.FlightBookingSystem.entity.Passenger;


public interface PassengerRepository extends JpaRepository<Passenger, Integer> {
	
	Optional<Passenger> findByContactNumber(Long contactNumber);
	
	
}
