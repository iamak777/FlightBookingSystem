package com.FlightBookingSystem.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.FlightBookingSystem.dto.ResponseStructure;
import com.FlightBookingSystem.entity.Payment;
import com.FlightBookingSystem.enums.Mode;
import com.FlightBookingSystem.enums.Status;
import com.FlightBookingSystem.services.PaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController {
	@Autowired
	private PaymentService paymentService;
	
	@PostMapping
	public ResponseEntity<ResponseStructure<Payment>> addPassenger(@RequestBody Payment payment){
		return paymentService.recordPayment(payment);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<ResponseStructure<Payment>> getPassengerByid(@PathVariable Integer id){
           return  paymentService.getPaymentById(id);
		}
	
	@GetMapping("/all")
	public ResponseEntity<ResponseStructure<List<Payment>>> getAllPayment(){
		return paymentService.getAllPayment();
	}
	
	@PutMapping("/{id}/{status}")
	public ResponseEntity<ResponseStructure<Payment>> updatePayment(@PathVariable Integer id , @PathVariable Status status){
		return paymentService.updatePayment(id , status);
	}
	
	@GetMapping("/status/{status}")
	public ResponseEntity<ResponseStructure<List<Payment>>> getPaymentByStatus(@PathVariable Status status){
		return paymentService.getPaymentByStatus(status);
	}
	
	@GetMapping("/mode/{mode}")
	public ResponseEntity<ResponseStructure<List<Payment>>> getPaymentByStatus(@PathVariable Mode mode){
		return paymentService.getPaymentByMode(mode);
	}
	
	// SORTING AND PAGING
	@GetMapping("/sortedpage/{pageNumber}/{pageSize}/{field}")
	public ResponseEntity<ResponseStructure<Page<Payment>>> getBookByPagination(@PathVariable Integer pageNumber ,@PathVariable Integer  pageSize , @PathVariable String field){
			return paymentService.getPaymentByPageAndSorted(pageNumber, pageSize, field);
}
	

}
