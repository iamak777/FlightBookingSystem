package com.FlightBookingSystem.exception;

public class RecordNotAvailableException extends RuntimeException{
	public RecordNotAvailableException(String message) {
		super(message);
	}

}
