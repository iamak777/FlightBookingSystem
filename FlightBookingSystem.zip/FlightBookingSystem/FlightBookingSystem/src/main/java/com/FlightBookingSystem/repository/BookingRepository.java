package com.FlightBookingSystem.repository;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import com.FlightBookingSystem.entity.Booking;
import com.FlightBookingSystem.entity.Passenger;
import com.FlightBookingSystem.entity.Payment;
import com.FlightBookingSystem.enums.Status;

public interface BookingRepository extends JpaRepository<Booking, Integer>{
	
	@Query("select b from Booking b where b.flight.id=:id")
	public List<Booking> getByFlightId(Integer id);
	
	@Query("select b from Booking b where FUNCTION('date', b.bookingDate)=:date")
	public List<Booking> getBookingByDate(LocalDate date);
	
	public List<Booking> findByStatus(Status status);
	
	@Query("select b.passenger from Booking b where b.id = :id")
	List<Passenger> getPassengerByBookinId(Integer id);
	
	@Query("select b.payment from Booking b where b.id = :id")
	Optional<Payment> getPaymentByBookinId(Integer id);
	
	
}
