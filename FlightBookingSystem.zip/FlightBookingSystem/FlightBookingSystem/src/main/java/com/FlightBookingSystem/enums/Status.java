package com.FlightBookingSystem.enums;

public enum Status {
	CONFIRM,
	WAITING,
	FAILED
}
