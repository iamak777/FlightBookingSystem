package com.FlightBookingSystem.enums;

public enum Gender {
	MALE,
	FEMALE,
	OTHERS
}
